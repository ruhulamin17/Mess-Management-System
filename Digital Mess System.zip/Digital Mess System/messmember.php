<?php 
    session_start();

    if($_SESSION['username']==null){
            if($_SESSION['password']==null){
                header("Location: login.php");
            }           
        }
    include("classes/loginandlogout.php");
    use App\classes\AdminLogin;
    $adm=new AdminLogin();
    if(isset($_GET['logout'])){
        $adm->adminLogout();
    }


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Mess System</title>

    <link rel="stylesheet" href="css/style.css">
</head>

    <?php
			include("include/config.php");
            include ("include/Database.php");
            $db= new Database();
	?>
		<?php
			$query= "select * from generalmember";
			$read= $db->select($query);
		 ?> 

<body style="background-color: #EEE8AE;">
    <div id="wrapper" style="background-color: white">
        <header>
            <div id="header">
                <h2>Digital Mess System</h2>
                <p>bachelor enjoying your life</p>
                <div id="logreg">
                        <a href="?logout=true"><span class="login">Logout</span></a>
                </div>

            </div>
        </header>
        <?php
            include ("include/nav.php");
	    ?>
       
        <div id="logincontent_wrapper">
            <div id="logincontent">
                <h2 style="text-align: center;color: #DC4C00;">Mess Members</h2><br>
                <div id="member">
                    <?php if($read){?>
                        <?php while($row =$read->fetch_assoc()){?>
                                <div id="m1">
                                    <img src="admin/<?php echo $row['image'];?>"><br>
                                    <span style="margin-left: 40px;">Name:</span>
                                    <span><?php echo $row['nam'];?></span><br>
                                    <span style="margin-left: 40px;">Phone No:</span>
                                    <span><?php echo $row['phone'];?></span><br>
                                    <span style="margin-left: 40px;">Email:</span>
                                    <span><?php echo $row['email'];?></span>
                                </div>
                    <?php } ?>
                    <?php } else{ ?>
                    <p>Data is not avilable !!</p>
                    <?php } ?>
                   
            
                </div>
                

            </div>
            <?php
                include ("include/sidebar.php");
	        ?>

        </div>
        <footer>
            <div id="footer">
                <span><a href="index.php">Home</a></span>
                <span><a href="#">About Us</a></span>
                <span><a href="#">Contact Us</a></span>
                <br>
                <br>
                <p>&copy; All Right Reserved By- Web Enginnering Lab</p>

            </div>
        </footer>

    </div>
  
</body>

</html>
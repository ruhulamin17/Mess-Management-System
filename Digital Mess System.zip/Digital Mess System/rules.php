<?php 
    session_start();

    if($_SESSION['username']==null){
            if($_SESSION['password']==null){
                header("Location: login.php");
            }           
        }
    include("classes/loginandlogout.php");
    use App\classes\AdminLogin;
    $adm=new AdminLogin();
    if(isset($_GET['logout'])){
        $adm->adminLogout();
    }


?>

            <?php
                    include("include/config.php");
                    include ("include/Database.php");

            ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Mess System</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body style="background-color: #EEE8AE;">
    <div id="wrapper">
        <header> 
            <div id="header">
                <h2>Digital Mess System</h2>
                <p>bachelor enjoying your life</p>
                <div id="logreg">
                        <a href="?logout=true"><span class="login">Logout</span></a>
                </div>

            </div>
        </header>
        <?php
            include ("include/nav.php");
	    ?>

        <?php
            $db= new Database();
			$query= "select * from rulespage";
			$read= $db->select($query);
		 ?>
       
        <div st id="mealcontent_wrapper">
        <div  id="aboutcontent">
                <h2 style="text-align: center;color: #DC4C00;">Our Mess Rules and Regulation</h2><br>
                <?php if($read){?>
                            <?php while($row =$read->fetch_assoc()){?>
                                    <img src="admin/<?php echo $row['image'];?>">
                                    <br>
                                    <br>
                                    <h2><?php echo $row['title'];?></h2>
                                    <br>
                                    <br>
                                    <p><?php echo $row['post'] ;?></p>
                    <?php } ?>
                    <?php } else{ ?>
                    <p>Data is not avilable !!</p>
                    <?php } ?>
                

            </div>
            <?php
                include ("include/sidebar.php");
	        ?>
            

        </div>
        <footer>
            <div id="footer">
                <span><a href="index.php">Home</a></span>
                <span><a href="about.php">About Us</a></span>
                <span><a href="contact.php">Contact Us</a></span>
                <br>
                <br>
                <p>&copy; All Right Reserved By- Web Enginnering Lab</p>

            </div>
        </footer>

    </div>
  
</body>

</html>
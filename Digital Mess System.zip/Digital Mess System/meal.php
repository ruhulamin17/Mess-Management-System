<?php 
    session_start();

    if($_SESSION['username']==null){
            if($_SESSION['password']==null){
                header("Location: login.php");
            }           
        }
    include("classes/loginandlogout.php");
    use App\classes\AdminLogin;
    $adm=new AdminLogin();
    if(isset($_GET['logout'])){
        $adm->adminLogout();
    }


?>

<!DOCTYPE html>
<html lang="en"> 

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Mess System</title>

    <link rel="stylesheet" href="css/style.css">
</head>

  <?php
			include("include/config.php");
            include ("include/Database.php");
            $db= new Database();
	?>
		<?php
			$query= "select * from meal";
			$read= $db->select($query);
		 ?>
    

<body style="background-color: #EEE8AE;">
    <div id="wrapper">
        <header>
            <div id="header">
                <h2>Digital Mess System</h2>
                <p>bachelor enjoying your life</p>
               <div id="logreg">
                  <a href="?logout=true"><span class="login">Logout</span></a>
                </div>

            </div>
        </header>
        <?php
            include ("include/nav.php");
	      ?>
       
        <div st id="mealcontent_wrapper">
            <div  id="mealcontent">
                <h2 style="text-align: center;color: #539DFA;">October Month - 2020</h2><br>
                <div id="tab">
                <table>
                    <tr>
                      <th>Name</th>
                      <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <th><?php echo $row['date'];?></th>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                      <th>Total Meal</th>
                    </tr>



                    <tr>
                        <?php
                            $query= "select * from meal";
                            $read= $db->select($query);
                          ?>
                         <td>Ruhul Amin</td>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $row['ruhul'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>


                          <?php
                            $query= "select sum(ruhul) from meal";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $ruhul=$row['sum(ruhul)'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>

                    </tr>

                    <tr>
                     <?php
                        $query= "select * from meal";
                        $read= $db->select($query);
                      ?>
                      <td>Nadir Ahmed</td>
                      <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $row['nadir'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>

                          <?php
                            $query= "select sum(nadir) from meal";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $nadir=$row['sum(nadir)'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                        
                    </tr>


                    <tr>
                    <?php
                        $query= "select * from meal";
                        $read= $db->select($query);
                      ?>
                      <td>Palash Barman</td>
                      <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $row['palash'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>

                          <?php
                            $query= "select sum(palash) from meal";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $palash=$row['sum(palash)'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                    </tr>



                    <tr>
                      <?php
                          $query= "select * from meal";
                          $read= $db->select($query);
                        ?>
                        <td>Nurnobi</td>
                        <?php if($read){?>
                                <?php while($row =$read->fetch_assoc()){?>
                                      <td><?php echo $row['nur'];?></td>                   
                            <?php } ?>
                            <?php } else{ ?>
                            <p>Data is not avilable !!</p>
                            <?php } ?>

                            <?php
                            $query= "select sum(nur) from meal";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $nur=$row['sum(nur)'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                            
                    </tr>


                    <tr>
                    <?php
                        $query= "select * from meal";
                        $read= $db->select($query);
                      ?>
                      <td>Majed Ahmed</td>
                      <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $row['majed'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                      
                          <?php
                            $query= "select sum(majed) from meal";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $majed=$row['sum(majed)'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                          
                    </tr>


                    <tr>
                        <?php
                            $query= "select * from meal";
                            $read= $db->select($query);
                          ?>
                          <td>Sayem</td>
                          <?php if($read){?>
                                  <?php while($row =$read->fetch_assoc()){?>
                                        <td><?php echo $row['sayem'];?></td>                   
                              <?php } ?>
                              <?php } else{ ?>
                              <p>Data is not avilable !!</p>
                              <?php } ?>
                          
                          <?php
                            $query= "select sum(sayem) from meal";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $sayem=$row['sum(sayem)'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                          
                    </tr>

                    <tr>
                        <?php
                            $query= "select * from meal";
                            $read= $db->select($query);
                          ?>
                          <td>Mubin</td>
                          <?php if($read){?>
                                  <?php while($row =$read->fetch_assoc()){?>
                                        <td><?php echo $row['gest_1'];?></td>                   
                              <?php } ?>
                              <?php } else{ ?>
                              <p>Data is not avilable !!</p>
                              <?php } ?>
                          
                          <?php
                            $query= "select sum(gest_1) from meal";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
                               <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $mubin=$row['sum(gest_1)'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                          
                    </tr>

                    <tr>
                        <?php
                            $query= "select * from meal";
                            $read= $db->select($query);
                          ?>
                          <td>Obi</td>
                          <?php if($read){?>
                                  <?php while($row =$read->fetch_assoc()){?>
                                        <td><?php echo $row['gest_2'];?></td>                   
                              <?php } ?>
                              <?php } else{ ?>
                              <p>Data is not avilable !!</p>
                              <?php } ?>
                          
                          <?php
                            $query= "select sum(gest_2) from meal";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
                               <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $obi=$row['sum(gest_2)'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                          
                    </tr>

                    <tr>
                        <?php
                            $query= "select * from meal";
                            $read= $db->select($query);
                          ?>
                          <td>Jafrul</td>
                          <?php if($read){?>
                                  <?php while($row =$read->fetch_assoc()){?>
                                        <td><?php echo $row['gest_3'];?></td>                   
                              <?php } ?>
                              <?php } else{ ?>
                              <p>Data is not avilable !!</p>
                              <?php } ?>
                          
                          <?php
                            $query= "select sum(gest_3) from meal";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
                               <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $jafrul=$row['sum(gest_3)'];?></td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                          
                    </tr>
                    
                  </table>
                  <?php

                   $total_meal= $ruhul+$palash+$nur+$nadir+$majed+$sayem+$mubin+$obi+$jafrul;?>

                   <h3 style="text-align: right; margin-right: 80px; background-color: #B8DBFB">Total Meal : <?php echo $total_meal;?>/=</h3>


                  <br>
                  <br>

                  

                


                  <h2 style="text-align: center;color: #539DFA;">Payment for Bazar Meal</h2><br>
                  <table style="margin:0 auto;">
                  
                  <tr>

                    <?php
                            $query= "select * from taka";
                            $read= $db->select($query);
                          ?>
                      <th>Name</th>
                      <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <th><?php echo $row['date'];?></th>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                      <th>Total Taka</th>


                    <tr>
                        <?php
                            $query= "select * from taka";
                            $read= $db->select($query);
                          ?>
                         <td>Ruhul Amin</td>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $row['ruhul'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>


                          <?php
                            $query= "select sum(ruhul) from taka";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $ruhul1=$row['sum(ruhul)'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>

                    </tr>

                    <tr>
                     <?php
                        $query= "select * from taka";
                        $read= $db->select($query);
                      ?>
                      <td>Nadir Ahmed</td>
                      <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $row['nadir'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>

                          <?php
                            $query= "select sum(nadir) from taka";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $nadir1=$row['sum(nadir)'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                        
                    </tr>


                    <tr>
                    <?php
                        $query= "select * from taka";
                        $read= $db->select($query);
                      ?>
                      <td>Palash Barman</td>
                      <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $row['palash'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>

                          <?php
                            $query= "select sum(palash) from taka";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $palash1=$row['sum(palash)'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                    </tr>



                    <tr>
                      <?php
                          $query= "select * from taka";
                          $read= $db->select($query);
                        ?>
                        <td>Nurnobi</td>
                        <?php if($read){?>
                                <?php while($row =$read->fetch_assoc()){?>
                                      <td><?php echo $row['nur'];?>/=</td>                   
                            <?php } ?>
                            <?php } else{ ?>
                            <p>Data is not avilable !!</p>
                            <?php } ?>

                            <?php
                            $query= "select sum(nur) from taka";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $nur1=$row['sum(nur)'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                            
                    </tr>


                    <tr>
                    <?php
                        $query= "select * from taka";
                        $read= $db->select($query);
                      ?>
                      <td>Majed Ahmed</td>
                      <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $row['majed'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                      
                          <?php
                            $query= "select sum(majed) from taka";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $majed1=$row['sum(majed)'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                          
                    </tr>


                    <tr>
                        <?php
                            $query= "select * from taka";
                            $read= $db->select($query);
                          ?>
                          <td>Sayem</td>
                          <?php if($read){?>
                                  <?php while($row =$read->fetch_assoc()){?>
                                        <td><?php echo $row['sayem'];?>/=</td>                   
                              <?php } ?>
                              <?php } else{ ?>
                              <p>Data is not avilable !!</p>
                              <?php } ?>
                          
                          <?php
                            $query= "select sum(sayem) from taka";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
			                         <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $sayem1=$row['sum(sayem)'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                          
                    </tr>

                     <tr>
                        <?php
                            $query= "select * from taka";
                            $read= $db->select($query);
                          ?>
                          <td>Mubin</td>
                          <?php if($read){?>
                                  <?php while($row =$read->fetch_assoc()){?>
                                        <td><?php echo $row['gest_1'];?>/=</td>                   
                              <?php } ?>
                              <?php } else{ ?>
                              <p>Data is not avilable !!</p>
                              <?php } ?>
                          
                          <?php
                            $query= "select sum(gest_1) from taka";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
                               <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $mubin1=$row['sum(gest_1)'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                          
                    </tr>

                     <tr>
                        <?php
                            $query= "select * from taka";
                            $read= $db->select($query);
                          ?>
                          <td>Obi</td>
                          <?php if($read){?>
                                  <?php while($row =$read->fetch_assoc()){?>
                                        <td><?php echo $row['gest_2'];?>/=</td>                   
                              <?php } ?>
                              <?php } else{ ?>
                              <p>Data is not avilable !!</p>
                              <?php } ?>
                          
                          <?php
                            $query= "select sum(gest_2) from taka";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
                               <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $obi1=$row['sum(gest_2)'];?>/=</td>                   
                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                          
                    </tr>

                     <tr>
                        <?php
                            $query= "select * from taka";
                            $read= $db->select($query);
                          ?>
                          <td>Jafrul</td>
                          <?php if($read){?>
                                  <?php while($row =$read->fetch_assoc()){?>
                                        <td><?php echo $row['gest_3'];?>/=</td>                   
                              <?php } ?>
                              <?php } else{ ?>
                              <p>Data is not avilable !!</p>
                              <?php } ?>
                          
                          <?php
                            $query= "select sum(gest_3) from taka";
                            $read= $db->select($query);
                          ?>
                          <?php if($read){?>
                               <?php while($row =$read->fetch_assoc()){?>
                                    <td><?php echo $jafrul1=$row['sum(gest_3)'];?>/=</td>      

                          <?php } ?>
                          <?php } else{ ?>
                          <p>Data is not avilable !!</p>
                          <?php } ?>
                          
                    </tr>
                  </table>
                  <?php

                   $total_taka= $ruhul1+$palash1+$nur1+$nadir1+$majed1+$sayem1+$mubin1+$obi1+$jafrul1;?>

                   <h3 style="text-align: right; margin-right: 160px;">Total Taka : <?php echo $total_taka;?>/=</h3>
                </div>


            </div>
            <br><br>
              <?php
                  $query= "select sum(amount) from messbazar";
                  $read= $db->select($query);
                ?>
                <?php if($read){?>
                     <?php while($row =$read->fetch_assoc()){?>
                              <span style="float:right;margin-right:170px;font-size:20px;font-weight: bold;"><td><?php echo $total_bazar=$row['sum(amount)'];?>/=</span>
                              <span style="float:right;margin-right:10px;font-size:20px;font-weight: bold;">Total Bazar Amount : </span><br>                   
                <?php } ?>
                <?php } else{ ?>
                <p>Data is not avilable !!</p>
                <?php } ?>

                <br>
                <?php
                  $meal_rate= $total_bazar/$total_meal;


                ?>
                <h3 style="text-align: center;">Meal Rate : <?php echo $meal_rate; ?> /=</h3>


                <br><br>
              <div id="tab">
                <table style="margin:0 auto;">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Total Taka</th>
                      <th>Total Meal Cost</th>
                      <th>Will Get</th>
                      <th>Will Give</th>
                    </tr>
                  </thead>
                  <tbody>
                      <tr> 
                          <td>Ruhul</td> 
                          <td><?php echo $ruhul1;?></td> 
                          <td>
                          <?php 
                            $ruhulmealcost = $ruhul*$meal_rate?>
                           <?php echo $ruhulmealcost;?>
                          </td> 
                          <?php 
                            $take= $ruhul1-$ruhulmealcost;

                          ?>
                          <td><?php
                            if($take>0){
                              echo $take;
                            }


                          ?></td> 
                          <td>
                            <?php
                             if($take<0){
                              echo $take;
                              }
                           ?>
                             
                          </td>                         
                      </tr>

                      <tr> 
                          <td>Sayem</td> 
                          <td><?php echo $sayem1;?></td> 
                          <td>
                            <?php
                              $sayemcost= $sayem*$meal_rate;
                              echo $sayemcost;

                            ?>
                          </td> 
                            
                            
                          <td>
                            <?php 
                              $take= $sayem1-$sayemcost;

                            ?>
                            <?php
                              if($take>0){
                                echo $take;
                              }


                            ?> 
                          </td> 
                          <td>
                            <?php
                             if($take<0){
                              echo $take;
                              }
                           ?>
                             
                          </td>                         
                      </tr>

                       <tr> 
                          <td>Palash</td> 
                          <td><?php echo $palash1;?></td> 
                          <td>
                            <?php
                              $palashcost= $palash*$meal_rate;
                              echo $palashcost;

                            ?>
                          </td> 
                            
                            
                          <td>
                            <?php 
                              $take= $palash1-$palashcost;

                            ?>
                            <?php
                              if($take>0){
                                echo $take;
                              }


                            ?> 
                          </td> 
                          <td>
                            <?php
                             if($take<0){
                              echo $take;
                              }
                           ?>
                             
                          </td>                         
                      </tr>

                       <tr> 
                          <td>Nadir</td> 
                          <td><?php echo $nadir1;?></td> 
                          <td>
                            <?php
                              $nadircost= $nadir*$meal_rate;
                              echo $nadircost;

                            ?>
                          </td> 
                            
                            
                          <td>
                            <?php 
                              $take= $nadir1-$nadircost;

                            ?>
                            <?php
                              if($take>0){
                                echo $take;
                              }


                            ?> 
                          </td> 
                          <td>
                            <?php
                             if($take<0){
                              echo $take;
                              }
                           ?>
                             
                          </td>                         
                      </tr>

                      <tr> 
                          <td>Nurnobi</td> 
                          <td><?php echo $nur1;?></td> 
                          <td>
                            <?php
                              $nurcost= $nur*$meal_rate;
                              echo $nurcost;

                            ?>
                          </td> 
                            
                            
                          <td>
                            <?php 
                              $take= $nur1-$nurcost;

                            ?>
                            <?php
                              if($take>0){
                                echo $take;
                              }


                            ?> 
                          </td> 
                          <td>
                            <?php
                             if($take<0){
                              echo $take;
                              }
                           ?>
                             
                          </td>                         
                      </tr>

                       <tr> 
                          <td>Majed</td> 
                          <td><?php echo $majed1;?></td> 
                          <td>
                            <?php
                              $majedcost= $majed*$meal_rate;
                              echo $majedcost;

                            ?>
                          </td> 
                            
                            
                          <td>
                            <?php 
                              $take= $majed1-$majedcost;

                            ?>
                            <?php
                              if($take>0){
                                echo $take;
                              }


                            ?> 
                          </td> 
                          <td>
                            <?php
                             if($take<0){
                              echo $take;
                              }
                           ?>
                             
                          </td>                         
                      </tr>

                      <tr> 
                          <td>Mubin</td> 
                          <td><?php echo $mubin1;?></td> 
                          <td>
                            <?php
                              $mubincost= $mubin*$meal_rate;
                              echo $mubincost;

                            ?>
                          </td> 
                            
                            
                          <td>
                            <?php 
                              $take= $mubin1-$mubincost;

                            ?>
                            <?php
                              if($take>0){
                                echo $take;
                              }


                            ?> 
                          </td> 
                          <td>
                            <?php
                             if($take<0){
                              echo $take;
                              }
                           ?>
                             
                          </td>                         
                      </tr>

                       <tr> 
                          <td>Obi</td> 
                          <td><?php echo $obi1;?></td> 
                          <td>
                            <?php
                              $obicost= $obi*$meal_rate;
                              echo $obicost;

                            ?>
                          </td> 
                            
                            
                          <td>
                            <?php 
                              $take= $obi1-$obicost;

                            ?>
                            <?php
                              if($take>0){
                                echo $take;
                              }


                            ?> 
                          </td> 
                          <td>
                            <?php
                             if($take<0){
                              echo $take;
                              }
                           ?>
                             
                          </td>                         
                      </tr>

                       <tr> 
                          <td>Jafrul</td> 
                          <td><?php echo $jafrul1;?></td> 
                          <td>
                            <?php
                              $jafrulcost= $jafrul*$meal_rate;
                              echo $jafrulcost;

                            ?>
                          </td> 
                            
                            
                          <td>
                            <?php 
                              $take= $jafrul1-$jafrulcost;

                            ?>
                            <?php
                              if($take>0){
                                echo $take;
                              }


                            ?> 
                          </td> 
                          <td>
                            <?php
                             if($take<0){
                              echo $take;
                              }
                           ?>
                             
                          </td>                         
                      </tr>





                      
                    </tbody>
                  </table>
                </div>

        </div>


        
        <footer>
            <div id="footer">
                <span><a href="index.php">Home</a></span>
                <span><a href="about.php">About Us</a></span>
                <span><a href="contact.php">Contact Us</a></span>
                <br>
                <br>
                <p>&copy; All Right Reserved By- Web Enginnering Lab</p>

            </div>
        </footer>

    </div>
  
</body>

</html>
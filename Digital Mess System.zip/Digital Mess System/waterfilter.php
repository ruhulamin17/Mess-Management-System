<?php 
    session_start();

    if($_SESSION['username']==null){
            if($_SESSION['password']==null){
                header("Location: login.php");
            }           
        }
    include("classes/loginandlogout.php");
    use App\classes\AdminLogin;
    $adm=new AdminLogin();
    if(isset($_GET['logout'])){
        $adm->adminLogout();
    }


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Mess System</title>

    <link rel="stylesheet" href="css/style.css">
</head>

        <?php
            include("include/config.php");
            include ("include/Database.php");
            $db= new Database();
        ?>

<body style="background-color: #EEE8AE;">
    <div id="wrapper">
        <header> 
            <div id="header">
                <h2>Digital Mess System</h2>
                <p>bachelor enjoying your life</p>
                <div id="logreg">
                        <a href="?logout=true"><span class="login">Logout</span></a>
                </div>

            </div>
        </header>
        <?php
            include ("include/nav.php");
	    ?>
       
        <div st id="mealcontent_wrapper">
            <div  id="mealcontent">
                <h2 style="text-align: center;color: #DC4C00;">Mess Water Filter Fulling List Janurary - 2020</h2><br>
                <div id="tab">
                  <table style="margin:0 auto;">
                    <tr>
                      <th>Name</th>
                      <th>Day</th>
                      <th>Morning</th>
                      <th>Evening</th>

                    </tr>
                    <?php
                            $query= "select * from messwater";
                            $read= $db->select($query);
                        ?>
                         
                          <?php if($read){?>
                                    <?php while($row =$read->fetch_assoc()){?>
                                     <tr>
                        
                                        <td><?php echo $row['name'];?></td> 
                                        <td><?php echo $row['day'];?></td>                   
                                        <td><?php echo $row['morning'];?></td>   
                                        <td><?php echo $row['evening'];?></td>                                                                     
                          
                                    </tr>
                        <?php } ?>
                        <?php } else{ ?>
                        <p>Data is not avilable !!</p>
                        <?php } ?>
                  </table>
                </div>
                

            </div>

        </div>
        <footer>
            <div id="footer">
                <span><a href="index.php">Home</a></span>
                <span><a href="about.php">About Us</a></span>
                <span><a href="contact.php">Contact Us</a></span>
                <br>
                <br>
                <p>&copy; All Right Reserved By- Web Enginnering Lab</p>

            </div>
        </footer>

    </div>
  
</body>

</html>
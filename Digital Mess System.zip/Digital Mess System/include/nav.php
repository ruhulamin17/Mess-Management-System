<nav>
            <div id="nav"> 
                <ul>
                    <li><a href="index.php"><div style="width: 30px;height: 30px;float: left;margin-right: 5px;"><img src="images/home1.png"></div>Home</a></li>
                    <li><a href="about.php"><div style="width: 30px;height: 30px;float: left;margin-right: 5px;"><img src="images/ab.png"></div>About Us</a></li>
                    <li><a href="#"><div style="width: 30px;height: 30px;float: left;margin-right: 5px;"><img src="images/mess.png"></div>Mess &raquo;</a>
                        <ul>
                            <li><a href="#">Mess Members&raquo;</a>
                                <ul>
                                    <li><a href="messmanager.php">Mess Manager</a></li>
                                    <li><a href="messmember.php">General Member</a></li>
                                </ul> 
                            </li>
                            <li><a href="meal.php">Meal System</a></li>
                            <li><a href="messbazar.php">Bazar System</a></li>
                            <li><a href="messclean.php">Mess Clean System</a></li>
                            <li><a href="washroomclean.php">Washroom Clean System</a></li>
                            <li><a href="waterfilter.php">Water filter System</a></li>
                            <li><a href="monthlypayment.php">Monthly Payment System</a></li>

                        </ul>
                    </li>
                    <li><a href="rules.php"><div style="width: 30px;height: 30px;float: left;margin-right: 5px;"><img src="images/rule.png"></div>Rules and Regulation</a></li>
                    <li><a href="contact.php"><div style="width: 30px;height: 30px;float: left;margin-right: 5px;"><img src="images/contact.png"></div>Contact Us</a></li>

                </ul>
                <div id="search_box">
				    <form action="search.php" method="get">
				    	<input type="text" name="search" placeholder="Search keyword...">
						<input type="submit" name="submit" value="Search">
				    </form>
			    </div>

            </div>
        </nav>
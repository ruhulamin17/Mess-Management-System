<div id="sidebar">
                <aside id="main_sidebar">
                    <h2>Sidebar</h2>
                    <ul>
                        <li><a href="messmanager.php">Mess Manager</a></li>
                        <li><a href="messmember.php">General Members</a></li>
                        <li><a href="meal.php">Meal System</a></li>
                        <li><a href="messbazar.php">Bazar System</a></li>
                        <li><a href="messclean.php">Mess Clean System</a></li>

                    </ul>

                </aside>
                <aside id="main_sidebar">
                    <ul>
                        <li><a href="washroomclean.php">Washroom Clean System</a></li>
                        <li><a href="waterfilter.php">Water filter System</a></li>
                        <li><a href="monthlypayment.php">Monthly Payment System</a></li>
                        <li><a href="messclean.php">Mess Clean System</a></li>

                    </ul>

                </aside>
               
            </div>
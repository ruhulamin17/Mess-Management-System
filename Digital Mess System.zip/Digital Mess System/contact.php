<?php 
    session_start();

    if($_SESSION['username']==null){
            if($_SESSION['password']==null){
                header("Location: login.php");
            }           
        }
    include("classes/loginandlogout.php");
    use App\classes\AdminLogin;
    $adm=new AdminLogin();
    if(isset($_GET['logout'])){
        $adm->adminLogout();
    }


?>


        <?php
            include ("include/config.php");
            include ("include/Database.php");
        ?>

       
<!DOCTYPE html> 
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Mess System</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body style="background-color: #EEE8AE;">
    <div id="wrapper">
        <header>
            <div id="header">
                <h2>Digital Mess System</h2>
                <p>bachelor enjoying your life</p>
                <div id="logreg">
                        <a href="?logout=true"><span class="login">Logout</span></a>
                </div>

            </div>
        </header>
        <?php
            include ("include/nav.php");
	    ?>

        <?php
				$db= new Database();
				if(isset($_POST['submit'])){
                    $nam = mysqli_real_escape_string($db->link, $_POST['nam']); 
					$email = mysqli_real_escape_string($db->link, $_POST['email']); 
					$sub = mysqli_real_escape_string($db->link, $_POST['sub']); 
					$messag = mysqli_real_escape_string($db->link, $_POST['messag']); 
					
				
					
						
					if($nam=='' || $email==''|| $sub==''|| $messag==''){
						$error="Field must not be Empty !!";
					}else{
						$query = "INSERT INTO contact(nam,email,sub,messag) Values('$nam','$email','$sub','$messag')";
						$create = $db->insert($query);
					}
				}
		?>
			 
			 <?php
				if(isset($error)){
					echo "<span style='color:red'>".$error."</span>";
				}
			 ?>
       
        <div st id="mealcontent_wrapper">
            <div  id="mealcontent">
                <div  id="aboutcontent">
                         <h1 style="text-align: center;color: #DC4C00;">Contact Us</h1><br>

                                <div id="inleft">
                                        <p>leave a message</p>
                                        <form action="contact.php" method="post" enctype="multipart/form-data">
                                            <input class="a" type="text" name="nam" placeholder="Your Name"><br> 
                                            <input class="a" type="text" name="email" placeholder="Your Email ID"><br> 
                                            <input class="a" type="text" name="sub" placeholder="Subject">
                                            <input class="b" type="text" name="messag" placeholder="Message"><br>
                                            <input class="c" type="submit" name="submit" value="Send Message">
                                        
                                        </form>
                                </div>
                
                

                </div>
                

            </div>
            <?php
                include ("include/sidebar.php");
	        ?>

        </div>
        <footer>
            <div id="footer">
                <span><a href="index.php">Home</a></span>
                <span><a href="about.php">About Us</a></span>
                <span><a href="contact.php">Contact Us</a></span>
                <br>
                <br>
                <p>&copy; All Right Reserved By- Web Enginnering Lab</p>

            </div>
        </footer>

    </div>
  
</body>

</html>
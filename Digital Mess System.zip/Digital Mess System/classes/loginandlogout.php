<?php
 namespace App\classes;
// use App\classes\Database;

	class AdminLogin{
		public function adminLogin($data){
			$connect=mysqli_connect("localhost","root","","digital_mess");

			$uname=$data['username'];
			$pass=$data['password'];

			$sql="select * from u_reg where username='$uname' and password='$pass'";
			if(mysqli_query($connect,$sql)){
				
				$queryResult=mysqli_query($connect,$sql);
				
				$admins=mysqli_fetch_assoc($queryResult);
				
				 if($admins){
					session_start();
					$_SESSION['username']=$admins['username'];
					$_SESSION['password']=$admins['password'];
					$_SESSION['id']=$admins['id'];

					header("Location: index.php");
				}

				else{
					$massage="Wrong username or password";
					return $massage;
				}
			}
			else{
				die("Query problem".mysqli_error($connect));
			}

		}

		public function adminLogout(){
			session_start();

			unset($_SESSION['username']);
			unset($_SESSION['password']);
			unset($_SESSION['id']);

			header("Location:login.php");
		}



		// public function changePass($data){
		// 	$connect=mysqli_connect("localhost","root","","digital_mess");

			

		// 	$sql="select * from login";
		// 	if(mysqli_query($connect,$sql)){
				
		// 		$queryResult=mysqli_query($connect,$sql);
				
		// 		$admins=mysqli_fetch_assoc($queryResult);

		// 		$old_password=$data['old_password'];
		// 		$new_password=$data['new_password'];

		// 		$sql="select * from login";
				
		// 		 if($admins){
		// 			$sql['password']=$admins['old_password'];

		// 			$sql = " UPDATE login
		//                     SET
		//                     password='$new_password'
		//                     WHERE id= $id";

		// 		}

		// 		else{
		// 				$massage1="password not correct";
		// 				return $massage1;
		// 			}
		// 	}

			

			 




	
	}
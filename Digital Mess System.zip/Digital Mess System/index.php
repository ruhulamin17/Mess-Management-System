<?php 
    session_start();

    if($_SESSION['username']==null){
            if($_SESSION['password']==null){
                header("Location: login.php");
            }           
        }
    include("classes/loginandlogout.php");
    use App\classes\AdminLogin;
    $adm=new AdminLogin();
    if(isset($_GET['logout'])){
        $adm->adminLogout();
    }


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Mess System</title>

    <link rel="stylesheet" href="css/style.css">
    <link href="css/slider.css" rel="stylesheet"/>
</head>

<body style="background-color: #EEE8AE;">
    <div id="wrapper">

    <?php
			include("include/config.php");
            include ("include/Database.php");
            $db= new Database();
	?>
		<?php
			$query= "select * from titleslogan";
			$read= $db->select($query);
		 ?>


        <header>
            <div id="header">
            <?php if($read){?>
			    <?php while($row =$read->fetch_assoc()){?>
                        <h2><?php echo $row['title'];?></h2>
                        <p><?php echo $row['slogan'];?></p>
                <?php } ?>
                <?php } else{ ?>
                <p>Data is not avilable !!</p>
                <?php } ?>


                <div id="logreg">
						<a href="?logout=true"><span class="login">Logout</span></a>
                </div>

            </div>
        </header>

        <?php
            include ("include/nav.php");
	    ?>
        
        <section>
            <div id="slider_wrapper">
                <div class="header_bottom_slider">  	  
                    <div class="slider_main">
                        <div class="slider effect">
                            <img src="images/1.png"/>
                        </div>
                        
                        <div class="slider effect">
                            <img src="images/2.jpg"/>
                        </div>
                        
                        <div class="slider effect">
                            <img src="images/8.jpg"/>
                        </div>
                        
                        <div class="slider effect">
                            <img src="images/9.jpg"/>
                        </div>
                    </div>
                    <script>
                    var index=0;
                    show();
                    function show(){
                        var i;
                        var slides=document.getElementsByClassName("slider");
                        for(i=0; i<slides.length; i++){
                            slides[i].style.display=" none";
                        }
                        index=index+1
                        if(index>slides.length){
                            index=1;
                        }	
                        slides[index-1].style.display="block";
                        setTimeout(show,2500);	
                    }	
                    
                    </script>		   
                </div>

               
            </div>
        </section>

        <?php
			$query= "select * from homepage";
			$read= $db->select($query);
		 ?>
        <div id="content_wrapper">
            <div id="content">
                <h3>Notices</h3>
                <article id="main_article_single">
                    <div id="imag_wrap">
                        <?php if($read){?>
                            <?php while($row =$read->fetch_assoc()){?>
                                <img src="admin/<?php echo $row['image'];?>" alt="">
                                <h2><?php echo $row['title'];?></h2>
                                <p><?php echo $row['post'] ;?></p>
                            <?php } ?>
							 <?php } else{ ?>
							 <p>Data is not avilable !!</p>
							 <?php } ?>
                    </div>
                </article>
                
            </div>
            <?php
                include ("include/sidebar.php");
	        ?>

        </div>
        <?php
			$query= "select * from copyright";
			$read= $db->select($query);
		 ?>
        <footer>
            <div id="footer">
                <span><a href="index.php">Home</a></span>
                <span><a href="about.php">About Us</a></span>
                <span><a href="contact.php">Contact Us</a></span>
                <br>
                <br>
                <?php if($read){?>
			    <?php while($row =$read->fetch_assoc()){?>
                        <p><?php echo $row['copyright'];?></p>
                <?php } ?>
                <?php } else{ ?>
                <p>Data is not avilable !!</p>
                <?php } ?>
                

            </div>
        </footer>

    </div>
  
</body>

</html>
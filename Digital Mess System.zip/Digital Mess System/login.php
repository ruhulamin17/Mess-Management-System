<?php
            session_start();

            if(isset($_SESSION['username'])){
                if(isset($_SESSION['password'])){
                    header("Location: index.php");
                }
                
            }


            include("classes/loginandlogout.php");
            use App\classes\AdminLogin;
            
            $admin=new AdminLogin();

            $massage='';
            if(isset($_POST['btn'])){

            $massage=$admin->adminLogin($_POST);
            }
    ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Mess System</title>

    <link rel="stylesheet" href="css/style.css">
    <link href="css/slider.css" rel="stylesheet"/>
</head>

<body style="background-color: #BBE6CD;">
    <div id="wrapper">
        
    
        <div id="logincontent_wrapper">
            <div id="logincontent">
                <div class="login_form">
                    <div class="login_contant">
                     <h2>Existing Members</h2>
                     <form name="loginform" action="" method="post" id="member" onsubmit="return validateform();">
                            <label>Username</label>
                            <input type="text" name="username" placeholder="Enter Username"  required>
                            <label>Password</label>
                            <input type="password" name="password" placeholder="Enter Password"  required><br>
                            <span style="color:red;font-size:25px;"><?php echo $massage; ?></span>
                            
                            <input type="submit" name="btn" value="SUBMIT">

                            <p>Don't have an account? <a href="register.php">Register Now</a></p>
                    </form>		
                    </div>	  
                 </div>
                
            </div>

        </div>

    </div>
  
</body>

</html>
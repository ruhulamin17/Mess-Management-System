<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Mess System</title>

    <link rel="stylesheet" href="css/style.css">
    <link href="css/slider.css" rel="stylesheet"/>
</head>

<body style="background-color: #BBE6CD;">
    <div id="wrapper">
    <?php
			include("include/config.php");
            include("include/Database.php");
            
        ?>
        
        <?php

        $db= new Database();
        if(isset($_POST['submit'])){

                    $username = mysqli_real_escape_string($db->link, $_POST['username']);  
                    $Fname = mysqli_real_escape_string($db->link, $_POST['fname']); 
                    $Lname = mysqli_real_escape_string($db->link, $_POST['lname']);
                    $Email = mysqli_real_escape_string($db->link, $_POST['email']);
                    $password = mysqli_real_escape_string($db->link, $_POST['password']);
                    $rpassword = mysqli_real_escape_string($db->link, $_POST['rpass']);
                    $Pnumber = mysqli_real_escape_string($db->link, $_POST['pnumber']);
                    $City = mysqli_real_escape_string($db->link, $_POST['city']);
                    $Pcode = mysqli_real_escape_string($db->link, $_POST['pcode']);

                    $permited  = array('jpg', 'jpeg', 'png', 'gif');
                    $file_name = $_FILES['image']['name'];
                    $file_size = $_FILES['image']['size'];
                    $file_temp = $_FILES['image']['tmp_name'];
                        
                    $div = explode('.', $file_name);
                    $file_ext = strtolower(end($div));
                    $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
                    $uploaded_image = "uploads/".$unique_image;

                        
                    
  
                    if($username=='' || $file_name==''||$Lname=='' || $Email==''|| $password==''|| $rpassword==''|| $Pnumber==''|| $City==''|| $Pcode==''){
                            $error="Field must not be Empty !!";
                    }elseif ($file_size >1048567) {
                            echo "<span class='error'>Image Size should be less then 1MB!
                            </span>";
                    } elseif (in_array($file_ext, $permited) === false) {
                            echo "<span class='error'>You can upload only:-"
                            .implode(', ', $permited)."</span>";
                    }else{
                            move_uploaded_file($file_temp, $uploaded_image);
                            $query = "INSERT INTO u_reg(username,fname,lname,email,password,rpass,image,pnumber,city,pcode) Values('$username','$Fname','$Lname','$Email','$password','$rpassword','$uploaded_image','$Pnumber','$City','$Pcode')";
                            $create = $db->insert($query);
                            if($create){
                                 header("Location: login.php");

                                }
                    }
            }
        ?>
      
       
        <div id="logincontent_wrapper">
            <div id="logincontent">
                <div class="registration_form">
                    <div class="registration_contant">
                    
                        <h2>Registration Form</h2>
                        <form name="registerform" action="" method="post" id="member" onsubmit="return validateform();" enctype="multipart/form-data">
                           <input type="text" name="username" placeholder="Username*">
                           <input type="text" name="fname" placeholder="First name*">
                           <input type="text" name="lname" placeholder="Last name*">
                           <input type="text" name="email" placeholder="E-mail*">
                           <input type="password" name="password" placeholder="password*">
                           <input type="password" name="rpass" placeholder="Retype password*"><br>
                           <span style="font-size: 15px;background-color:#E1E0D5;color:#000;padding:12px;">Add your Picture</span>
                           <input type="file" name="image" placeholder="Choose your picture*"><br><br>

                           
                            <p>Address Details</P>
                           <input type="text" name="pnumber" placeholder="Phone no*">
                           <input type="text" name="city" placeholder="City*">
                           <input type="text" name="pcode" placeholder="Post code*">
                           <div style="color:#fff;font-size:20px;" id="show"> </div>
                           <input type="submit" name="submit" value="SUBMIT">

                           <p>Already have an account? <a href="login.php">Login Now</a></p>
                         
        
                        </form>
                        <script>
                            function validateform(){
                                var Username = document.registerform.username;
                                var firstname = document.registerform.firstname;
                                var lastname = document.registerform.lastname;
                                var email = document.registerform.email;
                                var pass = document.registerform.pass;
                                var repass = document.registerform.repass;
                                var phoneno = document.registerform.phoneno;
                                var address = document.registerform.address;
                                var city = document.registerform.city;
                                var post = document.registerform.post;
                                if(Username.value == ""){
                                    document.getElementById("show").innerHTML="Please Enter Your Username";
                                    return false;
                                }
                                if(firstname.value == ""){
                                    document.getElementById("show").innerHTML="Please Enter Your FirstName";
                                    return false;
                                }
                                if(lastname.value == ""){
                                    document.getElementById("show").innerHTML="Please Enter Your LastName";
                                    return false;
                                }
                                if((email.value.indexOf('@',0) < 0) || (email.value.indexOf('.',0) < 0)){
                                    document.getElementById("show").innerHTML="Please Enter a Valid Email Address";
                                    return false;
                                }
                                if(pass.value == ""){
                                    document.getElementById("show").innerHTML="Please Enter Your PassWord";
                                    return false;
                                }
                                if(repass.value == ""){
                                    document.getElementById("show").innerHTML="Please Retype password";
                                    return false;
                                }
                                if(phoneno.value == ""){
                                    document.getElementById("show").innerHTML="Please Enter Your PhoneNumber";
                                    return false;
                                }
                                if(address.value == ""){
                                    document.getElementById("show").innerHTML="Please Enter Your Address";
                                    return false;
                                }
                                if(city.value == ""){
                                    document.getElementById("show").innerHTML="Please Enter Your City Address";
                                    return false;
                                }
                                if(post.value == ""){
                                    document.getElementById("show").innerHTML="Please Enter Your PostCode";
                                    return false;
                                }
                            }
                        </script>
                    </div>	  
              </div>
                
            </div>
           
        </div>
       

    </div>
  
</body>

</html>
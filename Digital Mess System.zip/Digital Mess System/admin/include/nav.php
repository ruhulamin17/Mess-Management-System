<nav>
            <div id="nav">
                <ul>
                    <li><a href="index.php"><div style="width: 24px;height: 21px;float: left;margin-right: 5px;"><img src="images/icon-dashboard.png"></div>Dashboard</a></li>
                    <li><a href="about.php"><div style="width: 24px;height: 21px;float: left;margin-right: 5px;"><img src="images/ab.png"></div>About Us</a></li>
                    <li><a href="#"><div style="width: 24px;height: 21px;float: left;margin-right: 5px;"><img src="images/mess.png"></div>Mess &raquo;</a>
                        <ul>
                            <li><a href="#">Mess Members&raquo;</a>
                                <ul>
                                    <li><a href="messmanager.php">Mess Manager</a></li>
                                    <li><a href="generalmember.php">General Member</a></li>
                                </ul> 
                            </li>
                            <li><a href="meal.php">Meal System</a></li>
                            <li><a href="messbazar.php">Bazar System</a></li>
                            <li><a href="messclean.php">Mess Clean System</a></li>
                            <li><a href="washclean.php">Washroom Clean System</a></li>
                            <li><a href="water.php">Water filter System</a></li>
                            <li><a href="monthlypayment.php">Monthly Payment System</a></li>

                        </ul>
                    </li>
                    <li><a href="contact.php"><div style="width: 24px;height: 21px;float: left;margin-right: 5px;"><img src="images/contact.png"></div>Contact Us</a></li>
                    <!-- <li><a href="contact.php"><div style="width: 24px;height: 21px;float: left;margin-right: 5px;"><img src="images/icon-form-style.png"></div>User Profile</a></li> -->
                    <li><a href="createchangepassword.php"><div style="width: 24px;height: 21px;float: left;margin-right: 5px;"><img src="images/pass.png"></div>Change Password</a></li>
                    <li><a href="../index.php"><div style="width: 24px;height: 21px;float: left;margin-right: 5px;"><img src="images/icon-charts-graphs.png"></div>Visit Website</a></li>


                </ul>

            </div>
        </nav>
       
        <div st id="content_wrapper">
            <div id="sidebar">
                <aside id="main_sidebar">
                    <ul>
                        <h3>Site Option</h3>
                        <li><a href="titleslogan.php">Title & Slogan </a></li>
                        <li><a href="copyright.php">Copyright</a></li>
                        <h3>Update Pages</h3>
                        <li><a href="home.php">Home Page</a></li>
                        <li><a href="about.php">About Us Page</a></li>
                        <li><a href="contact.php">Contact Us Page</a></li>
                        <li><a href="messmanager.php">Mess Manager</a></li>
                        <li><a href="generalmember.php">General Members</a></li>
                        <li><a href="meal.php">Meal System</a></li>
                        <li><a href="mealtaka.php">Money for Meal</a></li>
                        <li><a href="messbazar.php">Bazar System</a></li>
                        <li><a href="messclean.php">Mess Clean System</a></li>
                        <li><a href="washclean.php">Washroom Clean System</a></li>
                        <li><a href="water.php">Water filter System</a></li>
                        <li><a href="monthlypayment.php">Monthly Payment System</a></li>
                        <li><a href="rules.php">Rules and Regulation</a></li>
                        <h3>Category Option</h3>
                        <li><a href="category.php">Add Category</a></li>
                        <li><a href="createcategory.php">Category List</a></li>
                        

                    </ul>

                </aside>
               
            </div>
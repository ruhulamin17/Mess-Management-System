<footer>
            <div id="footer">
                <span><a href="index.php">Home</a></span>
                <span><a href="about.php">About Us</a></span>
                <span><a href="contact.php">Contact Us</a></span>
                <br>
                <br>
                <p>&copy; All Right Reserved By- Web Enginnering Lab</p>

            </div>
        </footer>

    </div>
  
</body>

</html>
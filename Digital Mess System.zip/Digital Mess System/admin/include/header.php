<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Digital Mess System</title>

    <link rel="stylesheet" href="css/logstyle.css">

</head>

<body style="background-color: #EEE8AE;">
    <div id="wrapper">
        <header>
            <div id="header">
                <h2>Digital Mess System</h2>
                <p>bachelor enjoying your life</p>

                <div id="right">
                    <div id="adimg">
                        <img src="images/img-profile.jpg" alt="Profile Pic" /></div>
                    <div id="adname">
                        <ul>
                            <li>Hello Admin</li>
                            <li><a href="?logout=true">Logout</a></li>
                        </ul>
                    </div>
                </div>





               <!--  <div id="search_box">
                    <form action="search.php" method="get">
                        <input type="text" name="search" placeholder="Search keyword...">
                        <input type="submit" name="submit" value="Search">
                    </form>
                </div> -->
               

            </div>
        </header>
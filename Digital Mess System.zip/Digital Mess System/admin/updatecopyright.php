<?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
        <?php
        include 'include/header.php';
        include ("include/config.php");
        include ("include/Database.php");
        include 'include/nav.php';
        
    ?>

        <?php
            $id=$_GET['id'];
            $db= new Database();
            $query= "SELECT * FROM copyright WHERE id=$id";
            $getData= $db->select($query)->fetch_assoc();
            ?>
        <?php
            if(isset($_POST['update'])){
                $copyright = mysqli_real_escape_string($db->link, $_POST['copyright']); 
                if($copyright==''){
                    $error="Field must not be Empty !!";
                }else{
                    $query = " UPDATE copyright
                    SET
                    copyright='$copyright',
                    WHERE id= $id";
                    $update = $db->update($query);
                }
            }
        ?>
		 <?php
                if(isset($_POST['delete'])){
                    $query="DELETE FROM copyright WHERE id=$id";
                    $deleteData = $db->delete($query);
                }
            ?>

        <?php
            if(isset($error)){
                echo "<span style='color:red'>".$error."</span>";
            }
        ?>

       
            <div  id="content">
                <div id="tsfull">
                    <h2>Update Copyright Text</h2>
                    <div id="tsin">               
                     <form action="updatecopyright.php?id=<?php echo $id;?>" method="post">
                        <table id="form">					
                            <tr>
                                <td>
                                    <label>Copyright Text</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['copyright']?>" name="copyright"  />
                                </td>
                            </tr>             
                            
                             <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="update" Value="Update" />
                                    <input class="but" type="reset" value="cancel" />
                                    <input class="but" type="submit" name="delete" value="Delete" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="copyright.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>
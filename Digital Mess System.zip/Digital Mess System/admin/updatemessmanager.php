<?php
            session_start();

            if($_SESSION['username']==null){
                    if($_SESSION['password']==null){
                        header("Location: login.php");
                    }			
                }
            include("classes/loginandlogout.php");
            use App\classes\AdminLogin;
            $adm=new AdminLogin();
            if(isset($_GET['logout'])){
                $adm->adminLogout();
            }


        ?>
        <?php
            include 'include/header.php';
            include ("include/config.php");
            include ("include/Database.php");
            include 'include/nav.php';

        ?>

            <?php
                $id=$_GET['id'];
                $db= new Database();
                $query= "SELECT * FROM messmanager WHERE id=$id";
                $getData= $db->select($query)->fetch_assoc();
            ?>
        <?php
            if(isset($_POST['update'])){
                $nam = mysqli_real_escape_string($db->link, $_POST['nam']); 
                $phone = mysqli_real_escape_string($db->link, $_POST['phone']);
                $email = mysqli_real_escape_string($db->link, $_POST['email']); 
                $Mon = mysqli_real_escape_string($db->link, $_POST['Mon']); 

                if($nam=='' || $phone==''|| $email==''|| $Mon==''){
                    $error="Field must not be Empty !!";
                }else{
                    $query = " UPDATE messmanager
                    SET
                    nam='$nam',
                    phone='$phone',
                    email='$email',
                    Mon='$Mon'
                    WHERE id= $id";
                    $update = $db->update($query);
                }
            }
        ?>
        <?php
            $query = "select * from messmanager where id='$id'";
            $getImg = $db->select($query);
            
            if(isset($_POST['delete'])){
                $query="DELETE FROM messmanager WHERE id=$id";
                $deleteData = $db->delete($query);	 
            //image delete from folder 	
                if ($getImg) {
                    while ($imgdata = $getImg->fetch_assoc()) {
                    $delimg = $imgdata['image'];
                    unlink($delimg);
                    }
                }
        
            }
        ?>


        
        
        <?php
            if(isset($error)){
                echo "<span style='color:red'>".$error."</span>";
            }
        ?>

       
            <div  id="content">
                <div id="tsfull">
                    <h2>Update Home Page Post</h2>
                    <div id="tsin">               
                     <form action="updatemessmanager.php?id=<?php echo $id;?>" method="post">
                        <table id="form">					
                            <tr>
                                <td>
                                    <label>Name</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['nam']?>" name="nam"  />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Phone No</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['phone']?>" name="phone"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Email</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['email']?>" name="email"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Month</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['Mon']?>" name="Mon"  />
                                </td>
                            </tr>
                             
                            
                             <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="update" Value="Update" />
                                    <input class="but" type="reset" value="cancel" />
                                    <input class="but" type="submit" name="delete" value="Delete" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="messmanager.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>
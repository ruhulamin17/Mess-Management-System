<?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


    ?>
        <?php
            include 'include/header.php';
            include ("include/config.php");
            include ("include/Database.php");
            include 'include/nav.php';
        
         ?>

        <?php
            $id=$_GET['id'];
            $db= new Database();
            $query= "SELECT * FROM messwash WHERE id=$id";
            $getData= $db->select($query)->fetch_assoc();
            ?>
        <?php
            if(isset($_POST['update'])){
                $name = mysqli_real_escape_string($db->link, $_POST['name']); 
                $date = mysqli_real_escape_string($db->link, $_POST['date']); 
                $day = mysqli_real_escape_string($db->link, $_POST['day']); 

                if($name=='' || $date=='' || $day==''){
                    $error="Field must not be Empty !!";
                }else{
                    $query = " UPDATE messwash
                    SET
                    name='$name',
                    date='$date',
                    day='$day'
                    WHERE id= $id";
                    $update = $db->update($query);
                }
            }
        ?>
		 <?php
                if(isset($_POST['delete'])){
                    $query="DELETE FROM messwash WHERE id=$id";
                    $deleteData = $db->delete($query);
                }
            ?>

        <?php
            if(isset($error)){
                echo "<span style='color:red'>".$error."</span>";
            }
        ?>

        
            <div  id="content">
                <div id="tsfull">
                    <h2>Update Mess Washroom Clean List</h2>
                    <div id="tsin">               
                     <form action="updatewashclean.php?id=<?php echo $id;?>" method="post">
                        <table id="form">	
                             <tr>
                                <td>
                                    <label>Name</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['name']?>" name="name"  />
                                </td>
                            </tr>				
                            <tr>
                                <td>
                                    <label>Date</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['date']?>" name="date"  />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>day</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['day']?>" name="day"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="update" Value="Update" />
                                    <input class="but" type="reset" value="cancel" />
                                    <input class="but" type="submit" name="delete" value="Delete" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="washclean.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?> 
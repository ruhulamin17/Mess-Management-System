 <?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
        <?php
            include 'include/header.php';
            include ("include/config.php");
            include ("include/Database.php");
            include 'include/nav.php';

        ?>


			 
			 <?php
				if(isset($error)){
					echo "<span style='color:red'>".$error."</span>";
				}
			 ?>

       
            <div  id="content">
                <div id="tsfull">

                    <h2>Update Site Title and Description</h2><br>
                     <?php
                            $db= new Database();
                            if(isset($_POST['submit'])){
                                $title = mysqli_real_escape_string($db->link, $_POST['title']); 
                                $slogan = mysqli_real_escape_string($db->link, $_POST['slogan']); 
                                
                            
                                
                                    
                                if($title=='' || $slogan==''){
                                    $error="Field must not be Empty !!";
                                }else{
                                    $query = "INSERT INTO titleslogan(title,slogan) Values('$title','$slogan')";
                                    $create = $db->insert($query);
                                    if($create){
                                        echo "<h2>Data Insert Successfully</h2>";

                                    }
                                }
                            }
                    ?>
                    <div id="tsin">               
                     <form action="createtitleslogan.php" method="post" enctype="multipart/form-data">
                        <table id="form">					
                            <tr>
                                <td>
                                    <label>Website Title</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter Website Title..."  name="title" class="medium" />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Website Slogan</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter Website Slogan..." name="slogan" class="medium" />
                                </td>
                            </tr>
                             
                            
                             <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="submit" Value="Update" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="titleslogan.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>
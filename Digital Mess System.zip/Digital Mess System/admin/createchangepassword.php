<?php
             session_start();

            if($_SESSION['username']==null){
                    if($_SESSION['password']==null){
                        header("Location: login.php");
                    }           
                }
            include("classes/loginandlogout.php");
            use App\classes\AdminLogin;
            $adm=new AdminLogin();
            if(isset($_GET['logout'])){
                $adm->adminLogout();
            }


        ?>
        <?php
            include ("include/config.php");
            include ("include/Database.php");
            include 'include/header.php';
            include 'include/nav.php';

        ?>
        <?php
            $db= new Database();
            $query= "select * from login";
            $read= $db->select($query);
         ?>
                 

       
            <div  id="content">
                <div id="tsfull">
                    <h2>Change your Password</h2>
                    <div id="tsin">               
                     <form action="" method="post">
                        <table id="form">	
                        <?php if($read){?>
                                <?php while($row =$read->fetch_assoc()){?>
                                				
                                     <tr>
                                        <td>
                                            <h2 style="margin-left: 100px;"> <?php echo $row['username']?> </h2>
                                        </td>
                                        <td Style="text-align:center;"><button style="margin-left: 40px;"><a style="text-decoration:none;color:red;font-size:20px;" href="updatechangepassword.php?id=<?php echo urlencode($row['id']);?>">Change Password</a></button></td>
                                    </tr>
                                   <?php } ?>
                                <?php } else{ ?>
                                <p>Data is not avilable !!</p>
                                <?php } ?>
                             
                            
                        
                        </table>
                        </form>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>
<?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
    <?php
        include 'include/header.php';
        include ("include/config.php");
        include ("include/Database.php");
        include 'include/nav.php';
        
    ?>

       
       
            <div  id="content">
              <h2 style="text-align: center;color: white;margin-top: 50px;font-size: 30px;">Welcome To Admin Panel</h2>

            </div>
                
                

        </div>
       
        <?php include("include/footer.php") ?>
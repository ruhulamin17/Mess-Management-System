<?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>

<?php include 'include/header.php';
	include ("include/config.php");
    include ("include/Database.php");
    include 'include/nav.php';
    
 ?>
  <?php
	$db= new Database();
	$query= "select * from contact";
	$read= $db->select($query);
 ?>
 
 <?php
	if(isset($_GET['msg'])){
		echo "<span style='color:green'>".$_GET['msg']."</span>";
	}
 ?>
 <?php
	if(isset($_GET['msg'])){
		echo "<span style='color:green'>".$_GET['msg']."</span>";
	}
 ?>

  

            <div  id="content">
                <div style="overflow: scroll;" id="tsfull">
                    <h2>Contact Us Information</h2>
                        <div id="tsin"> 
              
                            <table>
                                <tr>
                                    <th width="20%">Name</th>
                                    <th width="20%">Email</th>
                                    <th width="15%">Subject</th>
                                    <th width="45%">Message</th>
                                </tr>
                                <?php if($read){?>
                                <?php while($row =$read->fetch_assoc()){?>
                                <tr>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['nam'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['email'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['sub'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['messag'] ?></td>
                                </tr>
                                <?php } ?>
                                <?php } else{ ?>
                                <p>Data is not avilable !!</p>
                                <?php } ?>
                                

                            </table><br>
                                
                        
                        </div>
                </div>
            </div>
               
         </div>

            
 
 
 
 
  

     <?php include("include/footer.php")?>
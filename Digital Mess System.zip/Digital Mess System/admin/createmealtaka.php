 <?php 
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
        <?php
            include 'include/header.php';
            include ("include/config.php");
            include ("include/Database.php");
            include 'include/nav.php';

        ?>

        <?php
				$db= new Database();
				if(isset($_POST['submit'])){
                    $date = mysqli_real_escape_string($db->link, $_POST['date']); 
					$ruhul = mysqli_real_escape_string($db->link, $_POST['ruhul']); 
                    $palash = mysqli_real_escape_string($db->link, $_POST['palash']); 
					$majed = mysqli_real_escape_string($db->link, $_POST['majed']); 
					$sayem = mysqli_real_escape_string($db->link, $_POST['sayem']); 
					$nur = mysqli_real_escape_string($db->link, $_POST['nur']); 
					$nadir = mysqli_real_escape_string($db->link, $_POST['nadir']); 
                    $gest_1 = mysqli_real_escape_string($db->link, $_POST['gest_1']); 
                    $gest_2 = mysqli_real_escape_string($db->link, $_POST['gest_2']); 
                    $gest_3 = mysqli_real_escape_string($db->link, $_POST['gest_3']); 

                    $query = "INSERT INTO taka(date,ruhul,palash,majed,sayem,nur,nadir,gest_1,gest_2,gest_3) Values('$date','$ruhul','$palash','$majed','$sayem','$nur','$nadir','$gest_1','$gest_2','$gest_3')";
                    $create = $db->insert($query);
					
				
					
					}	
				
			
		
        ?>


			 
			 <?php
				if(isset($error)){
					echo "<span style='color:red'>".$error."</span>";
				}
			 ?>

      
            <div  id="content">
                <div style="overflow: scroll;" id="tsfull">
                    <h2>Update Money For Meal</h2>
                    <div id="tsin">               
                     <form action="createmealtaka.php" method="post" enctype="multipart/form-data">
                        <table id="form">	
                            <tr>
                                <td>
                                    <label>Date</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter the Date..."  name="date" class="medium" />
                                </td>
                            </tr>				
                            <tr>
                                <td>
                                    <label>Ruhul Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his Taka..."  name="ruhul" class="medium" />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Palash Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his Taka..." name="palash" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Majed Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his Taka..." name="majed" class="medium" />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Sayem Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his Taka..." name="sayem" class="medium" />
                                </td>
                            </tr> 
                            <tr>
                                <td>
                                    <label>Nurnobi Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his Taka..." name="nur" class="medium" />
                                </td>
                            </tr> 
                            <tr>
                                <td>
                                    <label>Nadir Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his Taka..." name="nadir" class="medium" />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label>Gest-1 Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his Taka..." name="gest_1" class="medium" />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label>Gest-2 Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his Taka..." name="gest_2" class="medium" />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label>Gest-3 Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his Taka..." name="gest_3" class="medium" />
                                </td>
                            </tr>
                             
                            
                             <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="submit" Value="Update" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="mealtaka.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>
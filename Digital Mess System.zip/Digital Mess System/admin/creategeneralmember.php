 <?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
        <?php
                include ('include/header.php');
                include ("include/config.php");
                include ("include/Database.php");
                include ('include/nav.php');

         ?>

                <?php
                    $db= new Database();
                    if(isset($_POST['submit'])){
                        $nam = mysqli_real_escape_string($db->link, $_POST['nam']); 
                        $phone = mysqli_real_escape_string($db->link, $_POST['phone']); 
                        $email = mysqli_real_escape_string($db->link, $_POST['email']);


                        
                        $permited  = array('jpg', 'jpeg', 'png', 'gif');
                        $file_name = $_FILES['image']['name'];
                        $file_size = $_FILES['image']['size'];
                        $file_temp = $_FILES['image']['tmp_name'];
                        
                        $div = explode('.', $file_name);
                        $file_ext = strtolower(end($div));
                        $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
                        $uploaded_image = "uploads/".$unique_image;
                        
                            
                        if($nam=='' || $file_name==''||$phone=='' || $email==''){
                            $error="Field must not be Empty !!";
                        }elseif ($file_size >1048567) {
                            echo "<span class='error'>Image Size should be less then 1MB!
                            </span>";
                        } elseif (in_array($file_ext, $permited) === false) {
                            echo "<span class='error'>You can upload only:-"
                            .implode(', ', $permited)."</span>";
                        }else{
                            move_uploaded_file($file_temp, $uploaded_image);
                            $query = "INSERT INTO generalmember(nam,image,phone,email) Values('$nam','$uploaded_image','$phone','$email')";
                            $create = $db->insert($query);
                        }
                    }
                ?>
			 
			 <?php
				if(isset($error)){
					echo "<span style='color:red'>".$error."</span>";
				}
			 ?>

       
            <div  id="content">
                <div id="tsfull">
                    <h2>Update General Member Information</h2>
                    <div id="tsin">               
                     <form action="creategeneralmember.php" method="post" enctype="multipart/form-data">
                        <table id="form">					
                            <tr>
                                <td>
                                    <label>Name</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter Website Title..."  name="nam" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Image</label>
                                </td>
                                <td>
                                    <input id="A" type="file" placeholder="Enter Website Title..."  name="image" class="medium" />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Phone No</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter Website Slogan..." name="phone" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Email</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter Website Slogan..." name="email" class="medium" />
                                </td>
                            </tr>
                            
                             <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="submit" Value="Update" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="generalmember.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>
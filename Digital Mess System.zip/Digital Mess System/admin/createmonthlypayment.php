 <?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?> 
        <?php
            include 'include/header.php';
            include ("include/config.php");
            include ("include/Database.php");
             include 'include/nav.php';

        ?>

        <?php
				$db= new Database();
				if(isset($_POST['submit'])){
                    $month = mysqli_real_escape_string($db->link, $_POST['month']); 
					$name = mysqli_real_escape_string($db->link, $_POST['name']); 
                    $ttaka = mysqli_real_escape_string($db->link, $_POST['ttaka']); 
                    $tmeal = mysqli_real_escape_string($db->link, $_POST['tmeal']); 
                    $wget = mysqli_real_escape_string($db->link, $_POST['wget']); 
                    $wgive = mysqli_real_escape_string($db->link, $_POST['wgive']); 
                    $comment = mysqli_real_escape_string($db->link, $_POST['comment']); 
					
				
					
						
					if($month=='' || $name=='' || $ttaka==''|| $tmeal==''|| $wget==''|| $wgive==''|| $comment==''){
						$error="Field must not be Empty !!";
					}else{
						$query = "INSERT INTO messpayment(month,name,ttaka,tmeal,wget,wgive,comment) Values('$month','$name','$ttaka','$tmeal','$wget','$wgive','$comment')";
						$create = $db->insert($query);
					}
				}
		?>
			 
			 <?php
				if(isset($error)){
					echo "<span style='color:red'>".$error."</span>";
				}
			 ?>

       
            <div  id="content">
                <div style="overflow: scroll;" id="tsfull">
                    <h2>Update Mess Monthly Payment</h2>
                    <div id="tsin">               
                     <form action="createmonthlypayment.php" method="post" enctype="multipart/form-data">
                        <table id="form">	
                            <tr>
                                <td>
                                    <label>Month</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter Month..."  name="month" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Name</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter name..."  name="name" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Total Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter Total taka..."  name="ttaka" class="medium" />
                                </td>
                            </tr>				
                            <tr>
                                <td>
                                    <label>Total Meal Cost</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter Meal..."  name="tmeal" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Will Get</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter taka..."  name="wget" class="medium" />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label>Will Give</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter the taka..."  name="wgive" class="medium" />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Comment</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter Comment..." name="comment" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="submit" Value="Add List" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="monthlypayment.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>
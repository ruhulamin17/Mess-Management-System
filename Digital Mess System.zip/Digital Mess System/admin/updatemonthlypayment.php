<?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
        <?php
            include 'include/header.php';
            include ("include/config.php");
            include ("include/Database.php");
            include 'include/nav.php';
        
         ?>

        <?php
            $id=$_GET['id'];
            $db= new Database();
            $query= "SELECT * FROM messpayment WHERE id=$id";
            $getData= $db->select($query)->fetch_assoc();
            ?>
        <?php
            if(isset($_POST['update'])){
                $month = mysqli_real_escape_string($db->link, $_POST['month']);
                $name = mysqli_real_escape_string($db->link, $_POST['name']); 
                $ttaka = mysqli_real_escape_string($db->link, $_POST['ttaka']); 
                $tmeal = mysqli_real_escape_string($db->link, $_POST['tmeal']); 
                $wget = mysqli_real_escape_string($db->link, $_POST['wget']); 
                $wgive = mysqli_real_escape_string($db->link, $_POST['wgive']); 
                $comment = mysqli_real_escape_string($db->link, $_POST['comment']); 

                if($month=='' || $name=='' || $ttaka==''|| $tmeal==''|| $wget==''|| $wgive==''|| $comment==''){
                    $error="Field must not be Empty !!";
                }else{
                    $query = " UPDATE messpayment
                    SET
                    month='$month',
                    name='$name',
                    ttaka='$ttaka',
                    tmeal='$tmeal',
                    wget='$wget',
                    wgive='$wgive',
                    comment='$comment'
                    WHERE id= $id";
                    $update = $db->update($query);
                }
            }
        ?>
		 <?php
                if(isset($_POST['delete'])){
                    $query="DELETE FROM messpayment WHERE id=$id";
                    $deleteData = $db->delete($query);
                }
            ?>

        <?php
            if(isset($error)){
                echo "<span style='color:red'>".$error."</span>";
            }
        ?>

        
            <div  id="content">
                <div id="tsfull">
                    <h2>Update Mess Monthly Payment</h2>
                    <div id="tsin">               
                     <form action="updatemessclean.php?id=<?php echo $id;?>" method="post">
                        <table id="form">	
                             <tr>
                                <td>
                                    <label>Month</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['month']?>" name="month"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Name</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['name']?>" name="name"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Total Taka</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['ttaka']?>" name="ttaka"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Total Meal Cost</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['tmeal']?>" name="tmeal"  />
                                </td>
                            </tr>				
                            <tr>
                                <td>
                                    <label>Will Get</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['wget']?>" name="wget"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Will Give</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['wgive']?>" name="wgive"  />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Comment</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['comment']?>" name="comment"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="update" Value="Update" />
                                    <input class="but" type="reset" value="cancel" />
                                    <input class="but" type="submit" name="delete" value="Delete" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="monthlypayment.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?> 
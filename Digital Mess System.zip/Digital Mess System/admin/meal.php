<?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>

<?php include 'include/header.php';
	include ("include/config.php");
    include ("include/Database.php");
    include 'include/nav.php';
    
 ?>
 <?php
	$db= new Database();
	$query= "select * from meal";
	$read= $db->select($query);
 ?>
 
 <?php
	if(isset($_GET['msg'])){
		echo "<span style='color:green'>".$_GET['msg']."</span>";
	}
 ?>

  
            <div  id="content">
                <div style="overflow: scroll;" id="tsfull">
                    <h2>Update Daily Meal</h2>
                        <div id="tsin"> 
              
                            <table>
                                <tr>
                                    <th width="10%">Date</th>
                                    <th width="10%">Ruhul</th>
                                    <th width="10%">Palash</th>
                                    <th width="10%">Majed</th>
                                    <th width="10%">Sayem</th>
                                    <th width="10%">Nurnobi</th>
                                    <th width="10%">Nadir</th>
                                    <th width="10%">Mubin</th>
                                    <th width="10%">Obi</th>
                                    <th width="10%">Jafrul</th>
                                    <th width="10%">Action</th>
                                </tr>
                                <?php if($read){?>
                                <?php while($row =$read->fetch_assoc()){?>
                                <tr>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['date'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['ruhul'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['palash'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['majed'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['sayem'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['nur'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['nadir'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['gest_1'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['gest_2'] ?></td>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['gest_3'] ?></td>
                                    <td Style="text-align:center;border:1px solid black;"><button><a style="text-decoration:none;color:red;font-size:20px;" href="updatemeal.php?id=<?php echo urlencode($row['id']);?>">Edit</a></button></td>
                                </tr>
                                <?php } ?>
                                <?php } else{ ?>
                                <p>Data is not avilable !!</p>
                                <?php } ?>
                                

                            </table><br>
                                <button style="margin-left:20px;background-color:green;height:40px;width:200px;border-radius:10px;border:2px solid red;"><a style="text-decoration:none;color:white;font-size:18px;" href="createmeal.php">Update Daily Meal</a></button><br><br>
                                
                        
                        </div>
                </div>
            </div>
               
         </div>

            
 
 
 
 
  

     <?php include("include/footer.php")?>
 <?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
        <?php
        include 'include/header.php';
        include ("include/config.php");
        include ("include/Database.php");
        include 'include/nav.php';
        
    ?>

        <?php
				$db= new Database();
				if(isset($_POST['submit'])){
					$copyright = mysqli_real_escape_string($db->link, $_POST['copyright']); 
					
				
					
						
					if($copyright==''){
						$error="Field must not be Empty !!";
					}else{
						$query = "INSERT INTO copyright(copyright) Values('$copyright')";
						$create = $db->insert($query);
					}
				}
		?>
			 
			 <?php
				if(isset($error)){
					echo "<span style='color:red'>".$error."</span>";
				}
			 ?>

      
            <div  id="content">
                <div id="tsfull">
                    <h2>Update Copyright Text</h2>
                    <div id="tsin">               
                     <form action="createcopyright.php" method="post" enctype="multipart/form-data">
                        <table id="form">					
                            <tr>
                                <td>
                                    <label>Copyright Text</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter Copyright Text..."  name="copyright" class="medium" />
                                </td>
                            </tr>
                            
                             <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="submit" Value="Update" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="copyright.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>
 <?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
        <?php
            include 'include/header.php';
            include ("include/config.php");
            include ("include/Database.php");
             include 'include/nav.php';

        ?>

        <?php
				$db= new Database();
				if(isset($_POST['submit'])){
                    $name = mysqli_real_escape_string($db->link, $_POST['name']); 
					$date = mysqli_real_escape_string($db->link, $_POST['date']); 
                    $day = mysqli_real_escape_string($db->link, $_POST['day']); 
                    
					
				
					
						
					if($name=='' || $date=='' || $day==''){
						$error="Field must not be Empty !!";
					}else{
						$query = "INSERT INTO messwash(name,date,day) Values('$name','$date','$day')";
						$create = $db->insert($query);
					}
				}
		?>
			 
			 <?php
				if(isset($error)){
					echo "<span style='color:red'>".$error."</span>";
				}
			 ?>

       
            <div  id="content">
                <div style="overflow: scroll;" id="tsfull">
                    <h2>Update Mess Clean List</h2>
                    <div id="tsin">               
                     <form action="createwashclean.php" method="post" enctype="multipart/form-data">
                        <table id="form">	
                            <tr>
                                <td>
                                    <label>Name</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter name..."  name="name" class="medium" />
                                </td>
                            </tr>				
                            <tr>
                                <td>
                                    <label>Date</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter the date..."  name="date" class="medium" />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Day</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter day..." name="day" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="submit" Value="Add List" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="washclean.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>
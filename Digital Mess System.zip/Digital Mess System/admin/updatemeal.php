<?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
        <?php
        include 'include/header.php';
        include ("include/config.php");
        include ("include/Database.php");
        include 'include/nav.php';
         
    ?>

        <?php
            $id=$_GET['id'];
            $db= new Database();
            $query= "SELECT * FROM meal WHERE id=$id";
            $getData= $db->select($query)->fetch_assoc();
            ?>
        <?php
            if(isset($_POST['update'])){
                $date = mysqli_real_escape_string($db->link, $_POST['date']); 
                $ruhul = mysqli_real_escape_string($db->link, $_POST['ruhul']); 
                $palash = mysqli_real_escape_string($db->link, $_POST['palash']); 
                $majed = mysqli_real_escape_string($db->link, $_POST['majed']); 
                $sayem = mysqli_real_escape_string($db->link, $_POST['sayem']); 
                $nur = mysqli_real_escape_string($db->link, $_POST['nur']); 
                $nadir = mysqli_real_escape_string($db->link, $_POST['nadir']);
                $gest_1 = mysqli_real_escape_string($db->link, $_POST['gest_1']);
                $gest_2 = mysqli_real_escape_string($db->link, $_POST['gest_2']);
                $gest_3 = mysqli_real_escape_string($db->link, $_POST['gest_3']);

            if($date=='' || $ruhul=='' || $palash==''|| $majed==''|| $sayem==''|| $nur==''|| $nadir==''|| $gest_1==''|| $gest_2==''|| $gest_3==''){
                    $error="Field must not be Empty !!";
            }else{
                    $query = " UPDATE meal
                    SET
                    date='$date',
                    ruhul='$ruhul',
                    palash='$palash',
                    majed='$majed',
                    sayem='$sayem',
                    nur='$nur',
                    nadir='$nadir',
                    gest_1='$gest_1',
                    gest_2='$gest_2',
                    gest_3='$gest_3'
                    WHERE id= $id";
                    $update = $db->update($query);
                }
            }
        ?>
		 <?php
                if(isset($_POST['delete'])){
                    $query="DELETE FROM meal WHERE id=$id";
                    $deleteData = $db->delete($query);
                }
            ?>

        <?php
            if(isset($error)){
                echo "<span style='color:red'>".$error."</span>";
            }
        ?>

       
            <div  id="content">
                <div style="overflow: scroll;" id="tsfull">
                    <h2>Update Daily Meal</h2>
                    <div id="tsin">               
                     <form action="updatemeal.php?id=<?php echo $id;?>" method="post">
                        <table id="form">	
                             <tr>
                                <td>
                                    <label>Date</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['date']?>" name="date"  />
                                </td>
                            </tr>				
                            <tr>
                                <td>
                                    <label>Ruhul Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['ruhul']?>" name="ruhul"  />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Palash Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['palash']?>" name="palash"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Majed Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['majed']?>" name="majed"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Sayem Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['sayem']?>" name="sayem"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Nurnobi Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['nur']?>" name="nur"  />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Nadir Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['nadir']?>" name="nadir"  />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label>Mubin Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['gest_1']?>" name="gest_1"  />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label>Obi Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['gest_2']?>" name="gest_2"  />
                                </td>
                            </tr>

                            <tr>
                                <td>
                                    <label>Jafrul Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" value="<?php echo $getData['gest_3']?>" name="gest_3"  />
                                </td>
                            </tr>
                             
                            
                             <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="update" Value="Update" />
                                    <input class="but" type="reset" value="cancel" />
                                    <input class="but" type="submit" name="delete" value="Delete" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="meal.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?> 
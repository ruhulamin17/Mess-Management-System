<?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>

<?php include 'include/header.php';
	include ("include/config.php");
    include ("include/Database.php");
    include 'include/nav.php';
    
 ?>
 <?php
	$db= new Database();
	$query= "select * from titleslogan";
	$read= $db->select($query);
 ?>
 
 <?php
	if(isset($_GET['msg'])){
		echo "<span style='color:green'>".$_GET['msg']."</span>";
	}
 ?>

  
            <div  id="content">
                <div id="tsfull">
                    <h2>Update Site Title and Description</h2>
                        <div id="tsin"> 
              
                            <table>
                                <tr>
                                    <th width="400px">Title</th>
                                    <th width="40%">slogan</th>
                                    <th width="15%">Action</th>
                                </tr> 
                                <?php if($read){?>
                                <?php while($row =$read->fetch_assoc()){?>
                                <tr>
                                    <td Style="font-size:20px;text-align:center;height:50px;border:1px solid black;"><?php echo $row['title'] ?></td>
                                    <td Style="font-size:20px;text-align:center;border:1px solid black;"><?php echo $row['slogan'] ?></td>
                                    <td Style="text-align:center;border:1px solid black;"><button><a style="text-decoration:none;color:red;font-size:20px;" href="updatetitleslogan.php?id=<?php echo urlencode($row['id']);?>">Edit</a></button></td>
                                </tr>
                                <?php } ?>
                                <?php } else{ ?>
                                <p>Data is not avilable !!</p>
                                <?php } ?>
                                

                            </table><br>
                                <button style="margin-left:20px;background-color:green;height:40px;width:200px;border-radius:10px;border:2px solid red;"><a style="text-decoration:none;color:white;font-size:18px;" href="createtitleslogan.php">Add Title and Slogan</a></button>
                        
                        </div>
                </div>
            </div>
               
         </div>

            
 
 
 
 
  

     <?php include("include/footer.php")?>
 <?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
        <?php
            include 'include/header.php';
            include ("include/config.php");
            include ("include/Database.php");
            include 'include/nav.php';

        ?>

        <?php
				$db= new Database();
				if(isset($_POST['submit'])){
                    $date = mysqli_real_escape_string($db->link, $_POST['date']); 
					$ruhul = mysqli_real_escape_string($db->link, $_POST['ruhul']); 
                    $palash = mysqli_real_escape_string($db->link, $_POST['palash']); 
					$majed = mysqli_real_escape_string($db->link, $_POST['majed']); 
					$sayem = mysqli_real_escape_string($db->link, $_POST['sayem']); 
					$nur = mysqli_real_escape_string($db->link, $_POST['nur']); 
					$nadir = mysqli_real_escape_string($db->link, $_POST['nadir']);
                    $gest_1 = mysqli_real_escape_string($db->link, $_POST['gest_1']);
                    $gest_2 = mysqli_real_escape_string($db->link, $_POST['gest_2']);
                    $gest_3 = mysqli_real_escape_string($db->link, $_POST['gest_3']); 
                    
					$query = "INSERT INTO meal(date,ruhul,palash,majed,sayem,nur,nadir,gest_1,gest_2,gest_3) Values('$date','$ruhul','$palash','$majed','$sayem','$nur','$nadir','$gest_1','$gest_2','$gest_3')";
                        $create = $db->insert($query);
				
				}
		?>
			 
			 <?php
				if(isset($error)){
					echo "<span style='color:red'>".$error."</span>";
				}
			 ?>

      
            <div  id="content">
                <div style="overflow: scroll;" id="tsfull">
                    <h2>Update Daily Meal</h2>
                    <div id="tsin">               
                     <form action="createmeal.php" method="post" enctype="multipart/form-data">
                        <table id="form">	
                            <tr>
                                <td>
                                    <label>Date</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter the Date..."  name="date" class="medium" />
                                </td>
                            </tr>				
                            <tr>
                                <td>
                                    <label>Ruhul Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his meal..."  name="ruhul" class="medium" />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Palash Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his meal..." name="palash" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Majed Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his meal..." name="majed" class="medium" />
                                </td>
                            </tr> 
                            <tr>
                                <td>
                                    <label>Sayem Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his meal..." name="sayem" class="medium" />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Nurnobi Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his meal..." name="nur" class="medium" />
                                </td>
                            </tr> 
                            <tr>
                                <td>
                                    <label>Nadir Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his meal..." name="nadir" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Mubin Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his meal..." name="gest_1" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Obi Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his meal..." name="gest_2" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Jafrul Meal</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter his meal..." name="gest_3" class="medium" />
                                </td>
                            </tr>
                             
                            
                             <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="submit" Value="Update" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="meal.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>
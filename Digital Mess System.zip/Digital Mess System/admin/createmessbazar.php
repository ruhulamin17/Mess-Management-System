 <?php
	session_start();

	if($_SESSION['username']==null){
			if($_SESSION['password']==null){
				header("Location: login.php");
			}			
		}
	include("classes/loginandlogout.php");
	use App\classes\AdminLogin;
	$adm=new AdminLogin();
	if(isset($_GET['logout'])){
		$adm->adminLogout();
	}


?>
        <?php
            include 'include/header.php';
            include ("include/config.php");
            include ("include/Database.php");
             include 'include/nav.php';

        ?>

        <?php
				$db= new Database();
				if(isset($_POST['submit'])){
                    $name = mysqli_real_escape_string($db->link, $_POST['name']); 
					$date = mysqli_real_escape_string($db->link, $_POST['date']); 
                    $des = mysqli_real_escape_string($db->link, $_POST['des']); 
					$amount = mysqli_real_escape_string($db->link, $_POST['amount']); 
                    
					
				
					
						
					if($name=='' || $date=='' || $des==''|| $amount==''){
						$error="Field must not be Empty !!";
					}else{
						$query = "INSERT INTO messbazar(name,date,des,amount) Values('$name','$date','$des','$amount')";
						$create = $db->insert($query);
					}
				}
		?>
			 
			 <?php
				if(isset($error)){
					echo "<span style='color:red'>".$error."</span>";
				}
			 ?>

       
            <div  id="content">
                <div style="overflow: scroll;" id="tsfull">
                    <h2>Update Daily Mess Bazar</h2>
                    <div id="tsin">               
                     <form action="createmessbazar.php" method="post" enctype="multipart/form-data">
                        <table id="form">	
                            <tr>
                                <td>
                                    <label>Name</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter name..."  name="name" class="medium" />
                                </td>
                            </tr>				
                            <tr>
                                <td>
                                    <label>Date</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter the date..."  name="date" class="medium" />
                                </td>
                            </tr>
                             <tr>
                                <td>
                                    <label>Description</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter bazar description..." name="des" class="medium" />
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <label>Total Amount</label>
                                </td>
                                <td>
                                    <input id="A" type="text" placeholder="Enter total amount..." name="amount" class="medium" />
                                </td>
                            </tr>
                            
                            <tr>
                                <td>
                                </td>
                                <td>
                                    <input class="but" type="submit" name="submit" Value="Update" />
                                </td>
                            </tr>
                        </table>
                        </form>
                        <button style="margin-left:20px;background-color:white;"> <a style="text-decoration:none;color:blue;font-size:20px;" href="messbazar.php">Go back</a></button>
                    </div>
                </div>
              

            </div>
                
                

        </div>
        <?php include("include/footer.php") ?>